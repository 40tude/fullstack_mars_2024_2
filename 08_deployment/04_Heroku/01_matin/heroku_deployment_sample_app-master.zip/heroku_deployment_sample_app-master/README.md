# Heroku deployment - Sample app

This is a repo containing sample Docker app to deploy to Heroku. If you want to see the end result, simple go this url: 

* https://jedha-streamlit-demo.herokuapp.com/

If you want to follow along, simple clone this repo:

* `git clone https://github.com/JedhaBootcamp/heroku_deployment_sample_app` 

Happy coding 😀 
