# Fast API Demo App 

Welcome to [Jedha](https://jedha.co) fast api demo app. Simply `git clone` this repository to checkout how to works. You can play around with it !

Check out deployed app here: 

* [Jedha demo api](https://jedha-fast-api-demo.herokuapp.com/)

Enjoy 😎