print("Hello World from Jedha!")
print("This is Volumes magical powers 🪄")