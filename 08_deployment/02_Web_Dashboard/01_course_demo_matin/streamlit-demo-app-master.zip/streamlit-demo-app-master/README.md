# Streamlit Demo app 

Welcome to this streamlit demo app. The goal of this application is to quickly onboard you on `streamlit`'s functionalities. If you want to check out
the end work, simply go to this URL --> https://jedha-streamlit-demo.herokuapp.com/

## Checkout code 

If you want to checkout the code, simply run this command on your terminal:

`git clone https://github.com/JedhaBootcamp/streamlit-demo-app` 

Then you will be able to see `app.py` where the whole code is commented.

Happy coding 😀 
