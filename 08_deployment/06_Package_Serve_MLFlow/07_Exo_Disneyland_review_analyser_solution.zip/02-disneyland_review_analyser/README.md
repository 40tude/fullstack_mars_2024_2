# TO MAKE SOLUTION WORK 

To make solution work, don't forget to export environment variables: 

```bash
export MLFLOW_EXPERIMENT_ID=""
export MLFLOW_TRACKING_URI=""
export AWS_ACCESS_KEY_ID=""
export AWS_SECRET_ACCESS_KEY=""
export BACKEND_STORE_URI=""
export ARTIFACT_ROOT=""
```